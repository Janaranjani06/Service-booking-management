package com.cognizant.authorization;

import org.junit.Test;
import org.springframework.boot.SpringApplication;

//@SpringBootTest
public class AuthorizationServiceApplicationTests {



	@Test
	public void main() {
		
		SpringApplication.run(AuthorizationServiceApplication.class, new String[] {});
	}

}
