package com.cts.servicebookingmanagement.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.servicebookingmanagement.model.AppServiceReqReport;

@FeignClient(contextId="serviceReqReport",url="${user.feign.client}", name="${user.feign.name}")
public interface UserClient2 {
	
	@GetMapping("/awsBooking")
	public String welcome();
	
	@PostMapping("/user")
	public AppServiceReqReport registerUser(@RequestBody AppServiceReqReport appUser);
    
	@GetMapping("/user")
	public List<AppServiceReqReport> getUsers();
	
	@DeleteMapping("/deleteUsers")
	public void deleteUser(@RequestParam Integer id);
	
	@PutMapping("/user")
	public AppServiceReqReport updateStudent(@RequestHeader(name="authorization",required = true)String token,@RequestBody AppServiceReqReport appUser);
	
	@GetMapping("/user/{id}")
	public AppServiceReqReport getUserById(@PathVariable("id") Integer id);
}
