package com.cts.productmanagement.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.productmanagement.model.AppProduct;


@FeignClient(url="${user.feign.client}", name="${user.feign.name}")
public interface UserClient {

	@GetMapping("/awsBooking")
	public String welcome();
	
    @PostMapping("/user")
	public AppProduct registerUser(@RequestBody AppProduct appUser);
    
	@GetMapping("/user")
	public List<AppProduct> getUsers();
	
	@DeleteMapping("/deleteUsers")
	public void deleteUser(@RequestParam Integer id);
	
	@PutMapping("/user")
	public AppProduct updateStudent(@RequestHeader(name="authorization",required = true)String token,@RequestBody AppProduct appUser);
	
	@GetMapping("/user/{id}")
	public AppProduct getUserById(@PathVariable("id") Integer id);
}
