

create table App_Product (id int Auto_increment, name varchar(255), make varchar(255),model int,cost int,created_Date Date);
CREATE SEQUENCE HIBERNATE_SEQUENCE START WITH 1 INCREMENT BY 1;
