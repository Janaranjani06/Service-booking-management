package com.cts.usermanagement.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cts.usermanagement.model.AppUser;

//coonect to the product microservice
@FeignClient(url="${product.feign.client}", name="${product.feign.name}")

public interface ProdClient {
	
	@GetMapping("/product/{id}")
	public AppUser getProductById(@PathVariable("id") int id);
	
	@GetMapping("/awsProduct")
	public String welcome();
	
	@GetMapping("/product")
	public List<AppUser> getProducts();
	
	@PostMapping("/product")
		public AppUser addProduct(@RequestBody AppUser appProduct);
	 
	@PutMapping("/product")
		public AppUser updateProduct(@RequestHeader(name="authorization",required = true)String token,@RequestBody AppUser appProduct);
	 
	@DeleteMapping("/product/{id}")
		public void deleteProduct(@PathVariable int id);
	
}
