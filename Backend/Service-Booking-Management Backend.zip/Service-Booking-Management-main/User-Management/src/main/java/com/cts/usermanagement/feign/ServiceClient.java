package com.cts.usermanagement.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.usermanagement.model.AppUser;

@FeignClient(url="${service.feign.client}", name="${service.feign.name}")

public interface ServiceClient {

	@GetMapping("/servicereq/{userid}")
	public AppUser getUserById(@PathVariable("userid") Integer userid);
	
	@GetMapping("/servicereq/{status}")
	public AppUser getServiceByStatus(@PathVariable("status") String status);
	
	@GetMapping("/servicereq/{report}")
	public AppUser getServiceByReport(@PathVariable("report") String report);
	
	@GetMapping("/servicereq/report")
	public List<AppUser> getAllBookingReport(@RequestHeader(name="authorization",required = true)String token);
	
	@GetMapping("/servicereq/report/{userid}")
	public AppUser getReportById(@PathVariable("userid") Integer userid);
	
	@GetMapping("/servicereq/report/{reportId}")
	public AppUser getReportByreportId(@PathVariable("reportId") Integer reportId);
	
	@GetMapping("/awsBooking")
	public String welcome();
	
	@GetMapping("/servicereq")
	public List<AppUser> getBooking();
	
	@PostMapping("/servicereq")
	public AppUser createBooking(@RequestBody AppUser appServiceReq);
	
	@PutMapping("/servicereq")
	public AppUser updateBooking(@RequestHeader(name="authorization",required = true)String token,@RequestBody AppUser appServiceReq);
	
	@DeleteMapping("/servicereq/{id}")
	public void deleteUser(@RequestParam Integer id);
	
	@PostMapping("/servicereq/report")
	public AppUser addReport(@RequestBody AppUser appServiceReqReport);
   
	@DeleteMapping("/servicereq/{reportId}")
	public void deleteReport(@PathVariable Integer reportId);
	
	
}
